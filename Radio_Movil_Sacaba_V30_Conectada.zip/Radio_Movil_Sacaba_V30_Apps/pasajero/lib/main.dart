import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://ealgmbygpkjtnarsphxe.supabase.co';
const publishableKey = 'sb_publishable_Ds94YlnzF1DOLSlky7mhKw_4uYhHwXS';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: publishableKey);
  runApp(const PassengerApp());
}

class PassengerApp extends StatelessWidget {
  const PassengerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Radio Móvil Sacaba',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF168447), useMaterial3: true),
    home: const PassengerGate(),
  );
}

class PassengerGate extends StatefulWidget {
  const PassengerGate({super.key});
  @override State<PassengerGate> createState() => _PassengerGateState();
}
class _PassengerGateState extends State<PassengerGate> {
  final sb = Supabase.instance.client;
  bool loading = true;
  bool logged = false;
  Map<String,dynamic>? profile;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final u = sb.auth.currentUser;
    if (u != null) {
      try {
        final p = await sb.from('profiles').select('id,full_name,phone,role,active').eq('id', u.id).maybeSingle();
        if (p != null && p['role'] == 'passenger' && p['active'] == true) {
          profile = p; logged = true;
        } else { await sb.auth.signOut(); }
      } catch (_) { await sb.auth.signOut(); }
    }
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return logged ? PassengerHome(profile: profile!) : LoginPage(onLogged: _load);
  }
}

class LoginPage extends StatefulWidget {
  final Future<void> Function() onLogged;
  const LoginPage({super.key, required this.onLogged});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(text: 'pasajero.prueba@gmail.com');
  final password = TextEditingController();
  bool busy = false;
  String msg = '';
  Future<void> login() async {
    setState(() { busy = true; msg = ''; });
    try {
      await Supabase.instance.client.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      await widget.onLogged();
    } on AuthException catch (e) { setState(() => msg = e.message); }
    catch (e) { setState(() => msg = 'No se pudo iniciar sesión: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Column(children: [
      const Text('🚕', style: TextStyle(fontSize: 56)),
      Text('Radio Móvil Sacaba', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), const Text('Pasajero'), const SizedBox(height: 28),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Correo', prefixIcon: Icon(Icons.email_outlined))),
      const SizedBox(height: 12), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña', prefixIcon: Icon(Icons.lock_outline))),
      const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : login, child: Text(busy ? 'Conectando…' : 'INICIAR SESIÓN'))),
      if (msg.isNotEmpty) ...[const SizedBox(height: 12), Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red))],
    ])))));
}

class PassengerHome extends StatefulWidget {
  final Map<String,dynamic> profile;
  const PassengerHome({super.key, required this.profile});
  @override State<PassengerHome> createState() => _PassengerHomeState();
}
class _PassengerHomeState extends State<PassengerHome> {
  final sb = Supabase.instance.client;
  final pickup = TextEditingController();
  final destination = TextEditingController();
  String message = 'Listo para solicitar';
  bool busy = false;
  Stream<List<Map<String,dynamic>>> get tripStream => sb.from('trips').stream(primaryKey: ['id']).order('created_at', ascending: false);

  Future<Position?> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
  }
  Future<void> requestTrip() async {
    if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) { setState(() => message = 'Completa origen y destino.'); return; }
    setState(() { busy = true; message = 'Obteniendo ubicación…'; });
    try {
      final pos = await locate();
      final row = await sb.from('trips').insert({
        'passenger_id': sb.auth.currentUser!.id,
        'pickup_address': pickup.text.trim(),
        'destination_address': destination.text.trim(),
        'pickup_lat': pos?.latitude,
        'pickup_lng': pos?.longitude,
        'status': 'requested',
        'estimated_fare': 10.00,
      }).select('id').single();
      setState(() => message = 'Solicitud #${row['id'].toString().substring(0,8)} enviada a Central.');
      pickup.clear(); destination.clear();
    } on PostgrestException catch (e) { setState(() => message = 'Error de Supabase: ${e.message}'); }
    catch (e) { setState(() => message = 'No se pudo solicitar: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> cancelTrip(String id) async {
    try { await sb.rpc('passenger_cancel_trip', params: {'p_trip_id': id}); setState(() => message = 'Viaje cancelado.'); }
    catch (e) { setState(() => message = 'No se pudo cancelar: $e'); }
  }
  Future<void> rateTrip(Map<String,dynamic> t) async {
    int stars = 5; final comment = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (ctx,setLocal) => AlertDialog(
      title: const Text('Calificar conductor'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(onPressed: () => setLocal(() => stars = i+1), icon: Icon(i < stars ? Icons.star : Icons.star_border)))),
        TextField(controller: comment, maxLines: 3, decoration: const InputDecoration(labelText: 'Comentario (opcional)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx,false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx,true), child: const Text('Enviar'))],
    )));
    if (ok != true) return;
    try { await sb.from('ratings').insert({'trip_id': t['id'], 'passenger_id': sb.auth.currentUser!.id, 'driver_id': t['driver_id'], 'stars': stars, 'comment': comment.text.trim().isEmpty ? null : comment.text.trim()}); setState(() => message = 'Gracias por tu calificación.'); }
    catch (e) { setState(() => message = 'No se pudo guardar la calificación: $e'); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('🚕 Radio Móvil Sacaba'), actions: [IconButton(onPressed: () async { await sb.auth.signOut(); if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const PassengerGate())); }, icon: const Icon(Icons.logout))]),
    body: StreamBuilder<List<Map<String,dynamic>>>(stream: tripStream, builder: (context,snap) {
      final uid = sb.auth.currentUser?.id;
      final rows = (snap.data ?? []).where((x) => x['passenger_id'] == uid).toList();
      final active = rows.where((x) => !['completed','cancelled'].contains(x['status'])).toList();
      return ListView(padding: const EdgeInsets.all(18), children: [
        Text('Hola, ${widget.profile['full_name'] ?? 'Pasajero'}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          TextField(controller: pickup, decoration: const InputDecoration(labelText: 'Origen', prefixIcon: Icon(Icons.my_location))),
          const SizedBox(height: 10), TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destino', prefixIcon: Icon(Icons.location_on))),
          const SizedBox(height: 14), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : requestTrip, icon: const Icon(Icons.local_taxi), label: Text(busy ? 'ENVIANDO…' : 'SOLICITAR MÓVIL'))),
          const SizedBox(height: 8), Text(message, textAlign: TextAlign.center),
        ]))),
        const SizedBox(height: 18),
        if (active.isNotEmpty) Text('Viaje en curso', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        ...active.map((t) => TripCard(t: t, onCancel: () => cancelTrip(t['id']), onRate: null)),
        if (rows.any((t) => t['status'] == 'completed')) ...[
          const SizedBox(height: 10), Text('Historial', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          ...rows.where((t) => t['status'] == 'completed').take(5).map((t) => TripCard(t: t, onCancel: null, onRate: t['driver_id'] == null ? null : () => rateTrip(t))),
        ],
      ];
    }),
  );
}

class TripCard extends StatelessWidget {
  final Map<String,dynamic> t; final VoidCallback? onCancel; final VoidCallback? onRate;
  const TripCard({super.key, required this.t, this.onCancel, this.onRate});
  String label(String s) => {'requested':'Buscando conductor','assigned':'Conductor asignado','accepted':'Conductor aceptó','arriving':'Conductor en camino','arrived':'Conductor llegó','started':'Viaje iniciado','completed':'Viaje finalizado','cancelled':'Cancelado'}[s] ?? s;
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label('${t['status']}'), style: const TextStyle(fontWeight: FontWeight.bold)),
    const SizedBox(height: 6), Text('📍 ${t['pickup_address'] ?? '-'}'), Text('🏁 ${t['destination_address'] ?? '-'}'),
    if (t['security_code'] != null && ['assigned','accepted','arriving','arrived','started'].contains(t['status'])) ...[const SizedBox(height: 6), Text('Código de viaje: ${t['security_code']}', style: const TextStyle(fontWeight: FontWeight.bold))],
    const SizedBox(height: 6), Text('Tarifa: Bs ${t['final_fare'] ?? t['estimated_fare'] ?? '-'}'),
    Row(mainAxisAlignment: MainAxisAlignment.end, children: [if (onCancel != null && ['requested','assigned','accepted','arriving','arrived'].contains(t['status'])) TextButton(onPressed: onCancel, child: const Text('Cancelar')), if (onRate != null) FilledButton.tonal(onPressed: onRate, child: const Text('Calificar'))]),
  ])));
}
