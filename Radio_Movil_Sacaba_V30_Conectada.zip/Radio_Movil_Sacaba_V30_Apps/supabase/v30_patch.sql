-- RADIO MÓVIL SACABA V30 — parche de compatibilidad y seguridad
-- Ejecutar en Supabase SQL Editor antes de probar V30.

-- 1. El esquema real usa profiles.active (no is_active).
create or replace function public.has_role(p_role public.app_role)
returns boolean
language sql stable security definer
set search_path = public
as $func$
  select exists (
    select 1 from public.profiles
    where id = auth.uid()
      and role = p_role
      and active = true
  );
$func$;
revoke all on function public.has_role(public.app_role) from public;
grant execute on function public.has_role(public.app_role) to authenticated;

-- 2. Evita que un pasajero pueda invocar el despacho automático directamente.
create or replace function public.assign_nearest_driver(p_trip_id uuid)
returns uuid
language plpgsql security definer set search_path=public
as $func$
declare
  v_trip public.trips%rowtype;
  v_driver uuid;
begin
  if not (public.has_role('dispatcher') or public.has_role('admin')) then
    raise exception 'Solo Central puede asignar conductores';
  end if;
  select * into v_trip from public.trips where id=p_trip_id and status='requested' for update;
  if not found then raise exception 'El viaje no está disponible para despacho'; end if;
  select dl.driver_id into v_driver
  from public.driver_locations dl
  join public.profiles p on p.id=dl.driver_id
  where dl.available=true and p.role='driver' and p.active=true
    and v_trip.pickup_lat is not null and v_trip.pickup_lng is not null
  order by power(dl.latitude-v_trip.pickup_lat,2)+power((dl.longitude-v_trip.pickup_lng)*cos(radians(v_trip.pickup_lat)),2)
  limit 1;
  if v_driver is null then return null; end if;
  update public.trips set driver_id=v_driver,status='assigned',assigned_at=now(),response_deadline=now()+interval '20 seconds',dispatch_attempt=coalesce(dispatch_attempt,0)+1,updated_at=now() where id=p_trip_id;
  update public.driver_locations set available=false,updated_at=now() where driver_id=v_driver;
  return v_driver;
end;
$func$;
revoke all on function public.assign_nearest_driver(uuid) from public;
grant execute on function public.assign_nearest_driver(uuid) to authenticated;

-- 3. Reforzar permisos de actualización directa: las transiciones del conductor usan RPC.
revoke update on public.trips from authenticated;

-- 4. Asegurar Realtime.
do $func$
begin
  alter publication supabase_realtime add table public.trips;
exception when duplicate_object then null; end
$func$;
do $func$
begin
  alter publication supabase_realtime add table public.driver_locations;
exception when duplicate_object then null; end
$func$;

-- Verificación rápida:
select id, full_name, role, active from public.profiles order by role;
