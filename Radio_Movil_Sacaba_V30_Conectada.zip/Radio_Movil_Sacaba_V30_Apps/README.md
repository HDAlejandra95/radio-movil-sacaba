# Radio Móvil Sacaba — V30 Conectada

V30 corrige la conexión real de las apps con Supabase y prepara el flujo completo Pasajero → Central → Conductor.

## Incluye
- App Flutter Pasajero con inicio de sesión, solicitud, seguimiento Realtime, cancelación y calificación.
- App Flutter Conductor con inicio de sesión, disponibilidad GPS, seguimiento Realtime y transiciones protegidas por RPC.
- Central web con login de dispatcher/admin, viajes, conductores disponibles y despacho automático.
- `supabase/v30_patch.sql` para corregir compatibilidad con `profiles.active` y restringir el despacho a Central.
- GitHub Actions para compilar ambos APK en release.

## Antes de probar
1. Ejecuta `supabase/v30_patch.sql` en Supabase.
2. Debe existir un usuario con rol `dispatcher` o `admin` para usar Central.
3. Los usuarios de prueba actuales pueden usarse para Pasajero y Conductor.
4. El conductor debe conceder permiso de ubicación y ponerse disponible.
5. El pasajero solicita el viaje; Central lo asigna; el conductor acepta y avanza el viaje.

## GitHub Actions
En Actions → `Compilar Radio Movil Sacaba` → `Run workflow`.
Al terminar, descarga los dos artefactos APK.

## Seguridad
La app usa únicamente la publishable key. Nunca colocar una `secret` o `service_role` en Flutter, navegador o repositorio.
