# Radio Móvil Sacaba — V33 Mejorada

V33 conecta de forma más segura la disponibilidad y ubicación del conductor con Supabase.

## Incluye
- App Pasajero Flutter
- App Conductor Flutter
- Central web
- Supabase Realtime
- Disponibilidad del conductor mediante RPC seguro
- Ubicación GPS del conductor
- Flujo de estados de viaje
- Workflow GitHub Actions para generar ambos APK

## Importante
1. Ejecutar `supabase/v32_patch.sql` en Supabase SQL Editor.
2. Luego subir este proyecto a GitHub y ejecutar Actions.
3. Instalar los nuevos APK V33.
4. En Conductor iniciar sesión y pulsar **PONERME DISPONIBLE**.
5. Central debe iniciar sesión con un perfil `dispatcher` o `admin` activo para asignar viajes.

Nunca colocar una clave `sb_secret_...` o `service_role` dentro de las apps.


## V34 – compilación Android corregida

El workflow genera el wrapper Android completo dentro de `pasajero/` y `conductor/` antes de compilar. Esto corrige el error `PathNotFoundException` observado en V33 al buscar `android/app/build.gradle`. Flutter documenta que las aplicaciones Android usan su proyecto Android/Gradle para la compilación.
