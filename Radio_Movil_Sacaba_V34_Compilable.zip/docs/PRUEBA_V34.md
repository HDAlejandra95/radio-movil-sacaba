# V34 – corrección de compilación

V33 falló porque el runner terminó sin un `android/app/build.gradle` válido. V34 evita copiar un wrapper Android temporal y genera el proyecto Android completo directamente dentro de cada aplicación con `flutter create --platforms=android`.

Después instala dependencias, ejecuta análisis y compila ambos APK en modo release.

Artefactos esperados:
- radio-movil-sacaba-pasajero-apk-v34
- radio-movil-sacaba-conductor-apk-v34
