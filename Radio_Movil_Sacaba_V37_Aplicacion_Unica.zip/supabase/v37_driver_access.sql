-- Radio Móvil Sacaba V37
-- Acceso de conductores por código único + vinculación a una instalación.
-- El inicio de sesión real se completa mediante la Edge Function driver-login.

create extension if not exists pgcrypto;

create table if not exists public.driver_access_codes (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles(id) on delete cascade,
  code_hash text not null unique,
  device_token text,
  device_bound_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists driver_access_codes_driver_idx
  on public.driver_access_codes(driver_id);

alter table public.driver_access_codes enable row level security;

-- No se exponen códigos desde el cliente. La Edge Function usa la clave de servicio.
drop policy if exists "driver_access_codes_no_direct_client_read" on public.driver_access_codes;

create or replace function public.driver_verify_access_code(
  p_code text,
  p_device_token text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_row public.driver_access_codes%rowtype;
  v_email text;
begin
  select * into v_row
  from public.driver_access_codes
  where code_hash = encode(extensions.digest(p_code, 'sha256'), 'hex')
    and is_active = true
  limit 1;

  if v_row.id is null then
    raise exception 'Código de conductor inválido.' using errcode = 'P0001';
  end if;

  if v_row.device_token is null then
    update public.driver_access_codes
      set device_token = p_device_token,
          device_bound_at = now(),
          updated_at = now()
    where id = v_row.id;
  elsif v_row.device_token <> p_device_token then
    raise exception 'Este código ya está vinculado a otro dispositivo.' using errcode = 'P0001';
  end if;

  select au.email into v_email
  from auth.users au
  join public.profiles p on p.id = au.id
  where p.id = v_row.driver_id
    and p.role = 'driver'
    and p.is_active = true;

  if v_email is null then
    raise exception 'El conductor no tiene una cuenta de acceso activa.' using errcode = 'P0001';
  end if;

  return jsonb_build_object(
    'driver_id', v_row.driver_id,
    'email', v_email,
    'device_bound', true
  );
end;
$$;

revoke all on function public.driver_verify_access_code(text, text) from public;
grant execute on function public.driver_verify_access_code(text, text) to anon, authenticated;

-- Ejemplo de alta para un conductor ya existente.
-- Sustituir DRIVER_UUID y SAC-001 por los datos reales.
-- insert into public.driver_access_codes(driver_id, code_hash)
-- values (
--   'DRIVER_UUID',
--   encode(extensions.digest('SAC-001', 'sha256'), 'hex')
-- );
