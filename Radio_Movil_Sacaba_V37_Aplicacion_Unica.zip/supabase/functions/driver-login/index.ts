// Radio Móvil Sacaba V37
// Edge Function para convertir el código único del conductor en una sesión Supabase.
// Requiere SUPABASE_URL, SUPABASE_ANON_KEY y SUPABASE_SERVICE_ROLE_KEY.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Método no permitido' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  try {
    const { code, device_token } = await req.json()
    if (!code || !device_token) {
      return new Response(JSON.stringify({ error: 'Faltan código o dispositivo.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    const url = Deno.env.get('SUPABASE_URL')!
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const admin = createClient(url, serviceKey)

    const { data, error } = await admin.rpc('driver_verify_access_code', {
      p_code: String(code).trim(),
      p_device_token: String(device_token),
    })

    if (error || !data?.email) {
      return new Response(JSON.stringify({
        error: error?.message ?? 'Código inválido o dispositivo no autorizado.',
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    // El código es la contraseña del usuario de Auth provisionado para ese conductor.
    const tokenResponse = await fetch(`${url}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: {
        apikey: anonKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: data.email,
        password: String(code).trim(),
      }),
    })

    const session = await tokenResponse.json()

    if (!tokenResponse.ok || !session.access_token || !session.refresh_token) {
      return new Response(JSON.stringify({
        error: 'El código fue validado, pero la cuenta de Auth del conductor todavía no está provisionada.',
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    return new Response(JSON.stringify({
      access_token: session.access_token,
      refresh_token: session.refresh_token,
      expires_in: session.expires_in,
      token_type: session.token_type,
      user: session.user,
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    })
  }
})
