-- Permite que cada usuario autenticado lea solamente su propio perfil.
-- Necesario para que la app única determine si entra como pasajero o conductor.

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
on public.profiles
for select
to authenticated
using (id = auth.uid());
