import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://ealgmbygpkjtnarsphxe.supabase.co';
const publishableKey = 'sb_publishable_Ds94YlnzF1DOLSlky7mhKw_4uYhHwXS';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: publishableKey);
  runApp(const DriverApp());
}

class DriverApp extends StatelessWidget {
  const DriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio Móvil Sacaba - Conductor',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF168447),
        useMaterial3: true,
      ),
      home: const DriverGate(),
    );
  }
}

class DriverGate extends StatefulWidget {
  const DriverGate({super.key});

  @override
  State<DriverGate> createState() => _DriverGateState();
}

class _DriverGateState extends State<DriverGate> {
  final sb = Supabase.instance.client;
  bool loading = true;
  Map<String, dynamic>? profile;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final user = sb.auth.currentUser;

    if (user != null) {
      try {
        final p = await sb
            .from('profiles')
            .select('id,full_name,phone,role,is_active')
            .eq('id', user.id)
            .maybeSingle();

        if (p != null && p['role'] == 'driver' && p['is_active'] == true) {
          profile = p;
        } else {
          await sb.auth.signOut();
        }
      } catch (_) {
        await sb.auth.signOut();
      }
    }

    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (profile != null) {
      return DriverHome(profile: profile!);
    }

    return DriverLogin(onLogged: _load);
  }
}

class DriverLogin extends StatefulWidget {
  final Future<void> Function() onLogged;

  const DriverLogin({super.key, required this.onLogged});

  @override
  State<DriverLogin> createState() => _DriverLoginState();
}

class _DriverLoginState extends State<DriverLogin> {
  final email = TextEditingController(text: 'conductor.prueba@gmail.com');
  final password = TextEditingController();
  bool busy = false;
  String msg = '';

  Future<void> login() async {
    setState(() {
      busy = true;
      msg = '';
    });

    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      await widget.onLogged();
    } on AuthException catch (e) {
      if (mounted) setState(() => msg = e.message);
    } catch (e) {
      if (mounted) setState(() => msg = 'No se pudo iniciar sesión: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              children: [
                const Text('🚕', style: TextStyle(fontSize: 56)),
                Text(
                  'Radio Móvil Sacaba',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text('Conductor'),
                const SizedBox(height: 28),
                TextField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Correo',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Contraseña',
                    prefixIcon: Icon(Icons.lock_outline),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy ? null : login,
                    child: Text(busy ? 'Conectando…' : 'INICIAR SESIÓN'),
                  ),
                ),
                if (msg.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(
                    msg,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.red),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DriverHome extends StatefulWidget {
  final Map<String, dynamic> profile;

  const DriverHome({super.key, required this.profile});

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final sb = Supabase.instance.client;
  bool available = false;
  bool busy = false;
  String message = 'Fuera de servicio';
  StreamSubscription<Position>? gps;

  Stream<List<Map<String, dynamic>>> get tripStream => sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false);

  Future<Position?> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return null;
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
      ),
    );
  }

  Future<void> setAvailable(bool value) async {
    final uid = sb.auth.currentUser?.id;
    if (uid == null) return;

    setState(() => busy = true);

    try {
      final pos = await locate();

      if (pos == null) {
        throw Exception('Activa la ubicación del teléfono.');
      }

      await sb.rpc(
        'driver_set_availability',
        params: {
          'p_available': value,
          'p_latitude': pos.latitude,
          'p_longitude': pos.longitude,
          'p_heading': pos.heading,
          'p_speed': pos.speed,
        },
      );

      await gps?.cancel();
      gps = null;

      if (value) {
        gps = Geolocator.getPositionStream(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 10,
          ),
        ).listen((position) async {
          try {
            await sb.rpc(
              'driver_set_availability',
              params: {
                'p_available': true,
                'p_latitude': position.latitude,
                'p_longitude': position.longitude,
                'p_heading': position.heading,
                'p_speed': position.speed,
              },
            );
          } catch (_) {}
        });
      }

      if (mounted) {
        setState(() {
          available = value;
          message = value
              ? '🟢 Disponible para recibir carreras'
              : '⚪ Fuera de servicio';
        });
      }
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => message = 'No se pudo cambiar disponibilidad: ${e.message}');
      }
    } catch (e) {
      if (mounted) setState(() => message = 'Error: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> action(String next, String id) async {
    try {
      if (next == 'accepted') {
        await sb.rpc(
          'driver_accept_trip',
          params: {'p_trip_id': id},
        );
      } else if (next == 'arriving') {
        await sb.rpc(
          'driver_start_arrival',
          params: {'p_trip_id': id},
        );
      } else if (next == 'arrived') {
        await sb.rpc(
          'driver_mark_arrived',
          params: {'p_trip_id': id},
        );
      } else if (next == 'started') {
        final code = await ask('Código de seguridad');
        if (code == null || code.isEmpty) return;

        await sb.rpc(
          'driver_start_trip',
          params: {
            'p_trip_id': id,
            'p_security_code': code,
          },
        );
      } else if (next == 'completed') {
        await sb.rpc(
          'driver_finish_trip',
          params: {
            'p_trip_id': id,
            'p_final_fare': 10.00,
          },
        );
      }

      if (mounted) {
        setState(() => message = 'Acción realizada correctamente.');
      }
    } on PostgrestException catch (e) {
      if (mounted) setState(() => message = 'No se pudo realizar la acción: ${e.message}');
    } catch (e) {
      if (mounted) setState(() => message = 'No se pudo realizar la acción: $e');
    }
  }

  Future<String?> ask(String title) async {
    final controller = TextEditingController();

    final result = await showDialog<String>(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: Text(title),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Código'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Validar'),
            ),
          ],
        );
      },
    );

    controller.dispose();
    return result;
  }

  @override
  void dispose() {
    gps?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = sb.auth.currentUser?.id;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🚕 Conductor'),
        actions: [
          IconButton(
            onPressed: () => setState(() {}),
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: () async {
              await sb.auth.signOut();
              if (!mounted) return;
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DriverGate()),
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: tripStream,
        builder: (context, snap) {
          final rows = (snap.data ?? [])
              .where(
                (x) =>
                    x['driver_id'] == uid &&
                    [
                      'assigned',
                      'accepted',
                      'arriving',
                      'arrived',
                      'started',
                    ].contains(x['status']),
              )
              .toList();

          final trip = rows.isEmpty ? null : rows.first;
          final status = trip == null ? null : '${trip['status']}';

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text(
                'Conductor: ${widget.profile['full_name'] ?? ''}',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: busy ? null : () => setAvailable(!available),
                  icon: Icon(
                    available ? Icons.toggle_on : Icons.toggle_off,
                  ),
                  label: Text(
                    available
                        ? 'PONERME OFFLINE'
                        : 'PONERME DISPONIBLE',
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: available
                      ? const Color(0xFFE8F5E9)
                      : const Color(0xFFF3F4F3),
                ),
                child: Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 18),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.local_taxi),
                  title: const Text('Carrera actual'),
                  subtitle: Text(
                    trip == null
                        ? 'Esperando asignación'
                        : 'Estado: $status',
                  ),
                ),
              ),
              if (trip != null) ...[
                const SizedBox(height: 8),
                Text('📍 ${trip['pickup_address'] ?? '-'}'),
                Text('🏁 ${trip['destination_address'] ?? '-'}'),
                if (trip['security_code'] != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    'Código: ${trip['security_code']}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
                const SizedBox(height: 14),
                if (status == 'assigned')
                  FilledButton(
                    onPressed: () => action('accepted', trip['id']),
                    child: const Text('ACEPTAR CARRERA'),
                  ),
                if (status == 'accepted')
                  FilledButton(
                    onPressed: () => action('arriving', trip['id']),
                    child: const Text('IR AL PASAJERO'),
                  ),
                if (status == 'arriving')
                  FilledButton(
                    onPressed: () => action('arrived', trip['id']),
                    child: const Text('YA LLEGUÉ'),
                  ),
                if (status == 'arrived')
                  FilledButton(
                    onPressed: () => action('started', trip['id']),
                    child: const Text('INICIAR VIAJE'),
                  ),
                if (status == 'started')
                  FilledButton(
                    onPressed: () => action('completed', trip['id']),
                    child: const Text('FINALIZAR VIAJE'),
                  ),
              ],
            ],
          );
        },
      ),
    );
  }
}
