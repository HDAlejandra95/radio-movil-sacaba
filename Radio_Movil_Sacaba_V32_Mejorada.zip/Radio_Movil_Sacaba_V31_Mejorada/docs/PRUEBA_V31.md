# Prueba funcional V31

1. Abrir APK Pasajero → iniciar sesión con `pasajero.prueba@gmail.com` y su contraseña.
2. Abrir APK Conductor → iniciar sesión con `conductor.prueba@gmail.com` y su contraseña.
3. En Conductor: activar ubicación y pulsar PONERME DISPONIBLE.
4. En Pasajero: colocar origen y destino y pulsar SOLICITAR MÓVIL.
5. En Central: iniciar sesión con dispatcher/admin y pulsar ASIGNAR CONDUCTOR MÁS CERCANO.
6. Conductor: ACEPTAR CARRERA → IR AL PASAJERO → YA LLEGUÉ → INICIAR VIAJE.
7. Pasajero: entregar el código de seguridad mostrado en su viaje al conductor.
8. Conductor: FINALIZAR VIAJE.
9. Pasajero: calificar al conductor.

Si una acción falla, copiar el mensaje exacto de Supabase y revisar primero que V31 patch haya sido ejecutado.
