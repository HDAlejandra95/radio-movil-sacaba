# Radio Móvil Sacaba — V32 Mejorada

V32 conecta de forma más segura la disponibilidad y ubicación del conductor con Supabase.

## Incluye
- App Pasajero Flutter
- App Conductor Flutter
- Central web
- Supabase Realtime
- Disponibilidad del conductor mediante RPC seguro
- Ubicación GPS del conductor
- Flujo de estados de viaje
- Workflow GitHub Actions para generar ambos APK

## Importante
1. Ejecutar `supabase/v32_patch.sql` en Supabase SQL Editor.
2. Luego subir este proyecto a GitHub y ejecutar Actions.
3. Instalar los nuevos APK V32.
4. En Conductor iniciar sesión y pulsar **PONERME DISPONIBLE**.
5. Central debe iniciar sesión con un perfil `dispatcher` o `admin` activo para asignar viajes.

Nunca colocar una clave `sb_secret_...` o `service_role` dentro de las apps.
