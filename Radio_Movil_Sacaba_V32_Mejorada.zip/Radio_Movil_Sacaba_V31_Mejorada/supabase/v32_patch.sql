-- RADIO MÓVIL SACABA V32
-- Disponibilidad segura del conductor + compatibilidad Central.

create or replace function public.driver_set_availability(
  p_available boolean,
  p_latitude double precision,
  p_longitude double precision,
  p_heading double precision default null,
  p_speed double precision default null
)
returns void
language plpgsql
security definer
set search_path = public
as $func$
begin
  if auth.uid() is null or not public.has_role('driver') then
    raise exception 'Solo un conductor activo puede cambiar su disponibilidad';
  end if;

  insert into public.driver_locations
    (driver_id, latitude, longitude, heading, speed, available, updated_at)
  values
    (auth.uid(), p_latitude, p_longitude, p_heading, p_speed, p_available, now())
  on conflict (driver_id) do update set
    latitude = excluded.latitude,
    longitude = excluded.longitude,
    heading = excluded.heading,
    speed = excluded.speed,
    available = excluded.available,
    updated_at = now();
end;
$func$;

revoke all on function public.driver_set_availability(boolean,double precision,double precision,double precision,double precision) from public;
grant execute on function public.driver_set_availability(boolean,double precision,double precision,double precision,double precision) to authenticated;

-- Central: el campo correcto del perfil es is_active.
-- Realtime ya debe incluir trips y driver_locations.

do $func$
begin
  alter publication supabase_realtime add table public.trips;
exception when duplicate_object then null; end
$func$;
do $func$
begin
  alter publication supabase_realtime add table public.driver_locations;
exception when duplicate_object then null; end
$func$;

select 'V32 OK' as resultado;
