# Radio Móvil Sacaba V18 — Android

Incluye dos proyectos Flutter independientes:
- `pasajero/`
- `conductor/`

## Funciones V18
### Pasajero
- Supabase Auth preparado.
- Solicitud de viaje.
- GPS.
- Escucha de estados en tiempo real.

### Conductor
- Disponible / offline.
- GPS periódico por movimiento.
- Recepción de viajes solicitados/asignados.
- Aceptar, ir, llegar y finalizar.
- Sincronización Realtime.

## Configuración
1. Instala Flutter.
2. En cada carpeta ejecuta `flutter pub get`.
3. Sustituye `supabaseUrl` y `publishableKey` en `lib/main.dart`.
4. Ejecuta `flutter run`.
5. Configura Supabase Auth/Phone y ejecuta el SQL de V17/V16.
6. En Android revisa permisos de ubicación y prueba en un teléfono real.

## APK
Esta entrega contiene el código fuente listo para compilar. El APK debe generarse en un entorno Flutter/Android con:
`flutter build apk --release`

No se incluye ninguna clave secreta. Usa únicamente la publishable key en la aplicación cliente.
