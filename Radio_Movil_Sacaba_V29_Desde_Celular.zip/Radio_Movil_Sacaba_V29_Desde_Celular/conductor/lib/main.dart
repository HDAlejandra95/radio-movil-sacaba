import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:geolocator/geolocator.dart';

const supabaseUrl = 'https://ealgmbygpkjtnarsphxe.supabase.co';
const publishableKey = 'sb_publishable_Ds94YlnzF1DOLSlky7mhKw_4uYhHwXS';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: publishableKey);
  runApp(const DriverApp());
}

class DriverApp extends StatelessWidget {
  const DriverApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Radio Móvil Sacaba Conductor',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF0C9648), useMaterial3: true),
    home: const DriverHome(),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final supabase = Supabase.instance.client;
  bool available = false;
  Stream<List<Map<String,dynamic>>>? trips;
  StreamSubscription<Position>? gps;
  String status = 'OFFLINE';

  @override
  void initState() {
    super.initState();
    trips = supabase.from('trips').stream(primaryKey: ['id']).order('created_at', ascending: false);
  }

  Future<void> toggle() async {
    final user = supabase.auth.currentUser;
    if (user == null) { setState(() => status = 'Inicia sesión'); return; }
    setState(() => available = !available);
    status = available ? 'DISPONIBLE' : 'OFFLINE';
    await supabase.from('driver_locations').upsert({
      'driver_id': user.id, 'latitude': 0, 'longitude': 0,
      'available': available, 'updated_at': DateTime.now().toIso8601String()
    });
    if (available) {
      gps?.cancel();
      gps = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10)
      ).listen((p) async {
        await supabase.from('driver_locations').upsert({
          'driver_id': user.id, 'latitude': p.latitude, 'longitude': p.longitude,
          'heading': p.heading, 'speed': p.speed, 'available': true,
          'updated_at': DateTime.now().toIso8601String()
        });
      });
    } else {
      await gps?.cancel();
      gps = null;
    }
    setState(() {});
  }

  Future<void> action(String id, String next) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    await supabase.from('trips').update({
      'status': next,
      if (next == 'accepted') 'accepted_at': DateTime.now().toIso8601String(),
      if (next == 'started') 'started_at': DateTime.now().toIso8601String(),
      if (next == 'completed') 'completed_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', id).eq('driver_id', user.id);
  }

  @override
  void dispose() { gps?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final uid = supabase.auth.currentUser?.id;
    return Scaffold(
      appBar: AppBar(title: const Text('🚕 Conductor · Radio Móvil Sacaba')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          FilledButton(onPressed: toggle, child: Text(available ? 'Pasar a OFFLINE' : 'PONERME DISPONIBLE')),
          const SizedBox(height: 8),
          Text(status, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 15),
          Expanded(child: StreamBuilder<List<Map<String,dynamic>>>(
            stream: trips,
            builder: (_, snap) {
              final rows = (snap.data ?? []).where((x) =>
                x['driver_id'] == uid || (x['driver_id'] == null && x['status'] == 'requested')).toList();
              return ListView(children: rows.map((t) {
                final s = t['status'];
                Widget? button;
                if (t['driver_id'] == uid && s == 'assigned') button = FilledButton(onPressed: () => action(t['id'], 'accepted'), child: const Text('Aceptar'));
                else if (t['driver_id'] == uid && s == 'accepted') button = FilledButton(onPressed: () => action(t['id'], 'arriving'), child: const Text('Voy al pasajero'));
                else if (t['driver_id'] == uid && s == 'arriving') button = FilledButton(onPressed: () => action(t['id'], 'arrived'), child: const Text('Llegué'));
                else if (t['driver_id'] == uid && s == 'started') button = FilledButton(onPressed: () => action(t['id'], 'completed'), child: const Text('Finalizar'));
                return Card(child: ListTile(
                  title: Text('${t['pickup_text']} → ${t['destination_text']}'),
                  subtitle: Text('Estado: $s'),
                  trailing: button,
                ));
              }).toList());
            },
          ))
        ]),
      ),
    );
  }
}
