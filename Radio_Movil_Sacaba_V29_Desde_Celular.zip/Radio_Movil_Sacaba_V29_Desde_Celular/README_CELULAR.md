# Radio Móvil Sacaba V29 — compilación desde celular

Este paquete deja preparados los dos proyectos Flutter (Pasajero y Conductor) y un GitHub Actions workflow que genera los APK en la nube, sin instalar Flutter en el celular.

## Qué necesitas
- Una cuenta de GitHub.
- Navegador del celular.
- Subir estos archivos a un repositorio nuevo.

## Importante
La clave incluida es una Supabase **publishable key**, apropiada para aplicaciones cliente. Nunca agregues una `sb_secret_...` ni una clave `service_role` al proyecto Flutter.

## Cómo compilar
1. Crea un repositorio nuevo en GitHub, por ejemplo `radio-movil-sacaba-app`.
2. Sube el contenido de esta carpeta conservando `.github/workflows/build-apk.yml`.
3. En GitHub abre **Actions** → **Build Radio Movil Sacaba APKs** → **Run workflow**.
4. Espera a que termine el trabajo.
5. Abre la ejecución terminada y entra a **Artifacts**.
6. Descarga `radio-movil-sacaba-pasajero-apk` y/o `radio-movil-sacaba-conductor-apk`.

## Limitación actual
Los APK se compilan en GitHub, pero la app todavía es una base técnica V18: falta completar autenticación de usuario, interfaz final, Google Maps/Routes, FCM y el flujo completo de producción.
