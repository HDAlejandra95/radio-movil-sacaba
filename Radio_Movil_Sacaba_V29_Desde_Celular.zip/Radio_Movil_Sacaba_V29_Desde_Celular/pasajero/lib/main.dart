import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:geolocator/geolocator.dart';

const supabaseUrl = 'https://ealgmbygpkjtnarsphxe.supabase.co';
const publishableKey = 'sb_publishable_Ds94YlnzF1DOLSlky7mhKw_4uYhHwXS';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: publishableKey);
  runApp(const PassengerApp());
}

class PassengerApp extends StatelessWidget {
  const PassengerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Radio Móvil Sacaba',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF0C9648), useMaterial3: true),
    home: const PassengerHome(),
  );
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final supabase = Supabase.instance.client;
  final pickup = TextEditingController();
  final destination = TextEditingController();
  Stream<List<Map<String,dynamic>>>? trips;
  String status = 'Listo para solicitar';

  @override
  void initState() {
    super.initState();
    trips = supabase.from('trips').stream(primaryKey: ['id']).order('created_at', ascending: false);
  }

  Future<Position?> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition();
  }

  Future<void> requestTrip() async {
    final user = supabase.auth.currentUser;
    if (user == null) { setState(() => status = 'Inicia sesión primero'); return; }
    if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) {
      setState(() => status = 'Completa origen y destino'); return;
    }
    final pos = await locate();
    await supabase.from('trips').insert({
      'passenger_id': user.id,
      'pickup_text': pickup.text.trim(),
      'destination_text': destination.text.trim(),
      'pickup_lat': pos?.latitude,
      'pickup_lng': pos?.longitude,
      'status': 'requested',
      'estimated_fare': 10
    });
    setState(() => status = 'Solicitud enviada a Central');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('🚕 Radio Móvil Sacaba')),
    body: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(children: [
        TextField(controller: pickup, decoration: const InputDecoration(labelText: 'Origen')),
        const SizedBox(height: 10),
        TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destino')),
        const SizedBox(height: 14),
        FilledButton(onPressed: requestTrip, child: const Text('Solicitar móvil')),
        const SizedBox(height: 12),
        Text(status),
        const SizedBox(height: 20),
        Expanded(child: StreamBuilder<List<Map<String,dynamic>>>(
          stream: trips,
          builder: (_, snap) {
            final rows = (snap.data ?? []).where((x) => x['passenger_id'] == supabase.auth.currentUser?.id).toList();
            return ListView(children: rows.map((t) => Card(
              child: ListTile(
                title: Text('${t['pickup_text']} → ${t['destination_text']}'),
                subtitle: Text('Estado: ${t['status']} · Bs ${t['final_fare'] ?? t['estimated_fare'] ?? '-'}'),
              ),
            )).toList());
          },
        ))
      ]),
    ),
  );
}
