# Radio Móvil Sacaba — V31 Mejorada

Versión preparada para generar APK Android mediante GitHub Actions.

Incluye:
- App Pasajero conectada a Supabase.
- App Conductor conectada a Supabase.
- Seguimiento de ubicación del conductor.
- Flujo de carrera: asignada → aceptada → en camino → llegó → iniciada → finalizada.
- Código de seguridad para iniciar viaje.
- Calificación del servicio en pasajero.
- Workflow moderno de GitHub Actions para generar ambos APK.
- Compatibilidad corregida con el esquema actual de `profiles` usando `is_active`.

## Compilación desde GitHub en el celular
1. Subir este ZIP al repositorio.
2. Abrir Actions.
3. Entrar a `Compilar Radio Movil Sacaba`.
4. Pulsar `Run workflow`.
5. Esperar a que termine en verde.
6. Abrir los artifacts y descargar los APK.

La clave de Supabase incluida es una clave publicable destinada al cliente. Nunca colocar una clave `sb_secret_...` o `service_role` dentro de las apps.
