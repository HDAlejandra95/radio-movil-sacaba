# Radio Móvil Sacaba V38 — Aplicación única

Esta versión reemplaza los dos APK separados por una sola aplicación.

## Flujo
- Al abrir: elegir **Pasajero** o **Conductor**.
- Pasajero: **Continuar con Google**.
- Conductor: **código único** y vinculación a una instalación/dispositivo.
- Después de autenticarse, la app carga el perfil y muestra el modo correspondiente.
- Central continúa siendo web y usa el mismo Supabase.

## Backend V38
1. Ejecutar `supabase/v37_profiles_policy.sql`.
2. Ejecutar `supabase/v37_driver_access.sql`.
3. Desplegar `supabase/functions/driver-login/index.ts` como función `driver-login`.
4. Configurar las variables de la Edge Function con los valores del proyecto. **Nunca colocar la service role key dentro del APK.**
5. En Supabase Auth habilitar Google y registrar el redirect móvil `bo.radiomovilsacaba://login-callback/`.
6. Provisionar cada código en `driver_access_codes`. El flujo de esta versión usa el código como contraseña de la cuenta Auth provisionada; la Edge Function evita exponer credenciales permanentes en la aplicación.

## Compilación GitHub
El workflow `.github/workflows/build-apk.yml` puede compilar `app/` directamente o extraer un ZIP V38 que contenga `app/pubspec.yaml`.


## V38
- OAuth Google móvil configurado explícitamente con PKCE.
- El callback `bo.radiomovilsacaba://login-callback/` intercambia el `code` mediante `exchangeCodeForSession`.
- No se cierra la pantalla de login inmediatamente después de iniciar OAuth.
- Trigger de Supabase para crear automáticamente el perfil `passenger` al crear un usuario nuevo por Google.
