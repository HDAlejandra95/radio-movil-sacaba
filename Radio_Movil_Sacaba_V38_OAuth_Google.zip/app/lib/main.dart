import 'dart:async';
import 'dart:convert';

import 'package:app_links/app_links.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://ealgmbygpkjtnarsphxe.supabase.co';
const publishableKey = 'sb_publishable_Ds94YlnzF1DOLSlky7mhKw_4uYhHwXS';
const oauthRedirect = 'bo.radiomovilsacaba://login-callback/';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: publishableKey,
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce,
      detectSessionInUri: false,
    ),
  );
  runApp(const RadioMovilApp());
}

class RadioMovilApp extends StatelessWidget {
  const RadioMovilApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio Móvil Sacaba',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2E6F49),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5FAF3),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: UnderlineInputBorder(),
        ),
      ),
      home: const AppGate(),
    );
  }
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});

  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  final sb = Supabase.instance.client;
  final appLinks = AppLinks();
  StreamSubscription<Uri>? linkSub;
  bool loading = true;
  Map<String, dynamic>? profile;

  @override
  void initState() {
    super.initState();
    _listenForOAuth();
    _loadSession();
  }

  Future<void> _listenForOAuth() async {
    try {
      final initial = await appLinks.getInitialLink();
      if (initial != null) await _handleLink(initial);
      linkSub = appLinks.uriLinkStream.listen(_handleLink);
    } catch (_) {}
  }

  Future<void> _handleLink(Uri uri) async {
    if (uri.scheme != 'bo.radiomovilsacaba') return;

    try {
      final error = uri.queryParameters['error'];
      if (error != null) {
        if (mounted) {
          setState(() {
            loading = false;
          });
        }
        return;
      }

      // Deep-link handling is disabled during Supabase.initialize() so the
      // callback cannot be consumed before this listener is ready.
      // getSessionFromUrl() then completes the PKCE callback here.
      await sb.auth.getSessionFromUrl(uri);
    } catch (e) {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
      return;
    }

    await _loadSession();
  }

  Future<void> _loadSession() async {
    final user = sb.auth.currentUser;
    Map<String, dynamic>? p;

    if (user != null) {
      try {
        p = await sb
            .from('profiles')
            .select('id,full_name,phone,role,is_active')
            .eq('id', user.id)
            .maybeSingle();
        if (p == null || p['is_active'] != true) {
          await sb.auth.signOut();
          p = null;
        }
      } catch (_) {
        await sb.auth.signOut();
        p = null;
      }
    }

    if (mounted) {
      setState(() {
        profile = p;
        loading = false;
      });
    }
  }

  @override
  void dispose() {
    linkSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (profile != null) {
      if (profile!['role'] == 'driver') {
        return DriverHome(profile: profile!);
      }
      return PassengerHome(profile: profile!);
    }
    return RoleChoicePage(onSessionChanged: _loadSession);
  }
}

class RoleChoicePage extends StatelessWidget {
  final Future<void> Function() onSessionChanged;

  const RoleChoicePage({super.key, required this.onSessionChanged});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                children: [
                  const Text('🚕', style: TextStyle(fontSize: 68)),
                  const SizedBox(height: 10),
                  Text(
                    'Radio Móvil Sacaba',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Seguro, rápido y siempre contigo.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 40),
                  _RoleButton(
                    icon: Icons.person_outline,
                    title: 'SOY PASAJERO',
                    subtitle: 'Solicita un móvil de forma rápida y segura',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PassengerLogin(
                          onLogged: onSessionChanged,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _RoleButton(
                    icon: Icons.local_taxi_outlined,
                    title: 'SOY CONDUCTOR',
                    subtitle: 'Acceso con código único de conductor',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DriverCodeLogin(
                          onLogged: onSessionChanged,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                  const Text(
                    'Una sola aplicación para toda la operación.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _RoleButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                child: Icon(icon, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(subtitle),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

class PassengerLogin extends StatefulWidget {
  final Future<void> Function() onLogged;
  const PassengerLogin({super.key, required this.onLogged});

  @override
  State<PassengerLogin> createState() => _PassengerLoginState();
}

class _PassengerLoginState extends State<PassengerLogin> {
  bool busy = false;
  String message = '';

  Future<void> loginGoogle() async {
    setState(() {
      busy = true;
      message = '';
    });
    try {
      await Supabase.instance.client.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: oauthRedirect,
        authScreenLaunchMode: LaunchMode.externalApplication,
      );
      // Do not close this page here. The deep-link callback must return to
      // AppGate, where the PKCE code is exchanged and the passenger profile
      // is loaded.
      if (mounted) {
        setState(() {
          message = 'Completa el acceso con Google…';
        });
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => message = e.message);
    } catch (e) {
      if (mounted) setState(() => message = 'No se pudo abrir Google: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Acceso pasajero')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              children: [
                const Text('👤', style: TextStyle(fontSize: 60)),
                const SizedBox(height: 14),
                Text(
                  'Ingresar como pasajero',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Usa tu cuenta de Google para acceder a Radio Móvil Sacaba.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: busy ? null : loginGoogle,
                    icon: const Text('G', style: TextStyle(fontWeight: FontWeight.bold)),
                    label: Text(busy ? 'ABRIENDO GOOGLE…' : 'CONTINUAR CON GOOGLE'),
                  ),
                ),
                if (message.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(message, textAlign: TextAlign.center),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DriverCodeLogin extends StatefulWidget {
  final Future<void> Function() onLogged;
  const DriverCodeLogin({super.key, required this.onLogged});

  @override
  State<DriverCodeLogin> createState() => _DriverCodeLoginState();
}

class _DriverCodeLoginState extends State<DriverCodeLogin> {
  final code = TextEditingController();
  bool busy = false;
  String message = '';

  Future<String> _deviceToken() async {
    final prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('driver_installation_token');
    if (token != null && token.isNotEmpty) return token;

    final info = DeviceInfoPlugin();
    String seed;
    try {
      final android = await info.androidInfo;
      seed = '${android.id}-${android.model}-${DateTime.now().microsecondsSinceEpoch}';
    } catch (_) {
      seed = DateTime.now().microsecondsSinceEpoch.toString();
    }
    token = base64Url.encode(utf8.encode(seed));
    await prefs.setString('driver_installation_token', token);
    return token;
  }

  Future<void> login() async {
    final value = code.text.trim();
    if (value.isEmpty) {
      setState(() => message = 'Ingresa tu código de conductor.');
      return;
    }

    setState(() {
      busy = true;
      message = '';
    });

    try {
      final device = await _deviceToken();
      final response = await Supabase.instance.client.functions.invoke(
        'driver-login',
        body: {
          'code': value,
          'device_token': device,
        },
      );

      final data = Map<String, dynamic>.from(response.data as Map);
      if (data['access_token'] == null || data['refresh_token'] == null) {
        throw Exception(data['error'] ?? 'Código inválido o dispositivo no autorizado.');
      }

      await Supabase.instance.client.auth.setSession(data['refresh_token'].toString());
      await widget.onLogged();
      if (mounted) Navigator.pop(context);
    } on PostgrestException catch (e) {
      if (mounted) setState(() => message = e.message);
    } on AuthException catch (e) {
      if (mounted) setState(() => message = 'Código aceptado, pero falta configurar el acceso del conductor.');
    } catch (e) {
      if (mounted) setState(() => message = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Acceso conductor')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              children: [
                const Text('🚕', style: TextStyle(fontSize: 60)),
                const SizedBox(height: 14),
                Text(
                  'Acceso de conductor',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Introduce el código único entregado por Central. El acceso se vincula a este dispositivo.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: code,
                  obscureText: true,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    labelText: 'Código de conductor',
                    prefixIcon: Icon(Icons.key_outlined),
                  ),
                  onSubmitted: (_) => login(),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton(
                    onPressed: busy ? null : login,
                    child: Text(busy ? 'VALIDANDO…' : 'INGRESAR'),
                  ),
                ),
                if (message.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(message, textAlign: TextAlign.center),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PassengerHome extends StatefulWidget {
  final Map<String, dynamic> profile;
  const PassengerHome({super.key, required this.profile});

  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final sb = Supabase.instance.client;
  final pickup = TextEditingController();
  final destination = TextEditingController();
  bool busy = false;
  String message = 'Listo para solicitar';

  Stream<List<Map<String, dynamic>>> get tripStream => sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false);

  Future<Position?> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
    );
  }

  Future<void> requestTrip() async {
    if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) {
      setState(() => message = 'Completa origen y destino.');
      return;
    }
    setState(() {
      busy = true;
      message = 'Obteniendo ubicación…';
    });
    try {
      final pos = await locate();
      await sb.from('trips').insert({
        'passenger_id': sb.auth.currentUser!.id,
        'pickup_address': pickup.text.trim(),
        'destination_address': destination.text.trim(),
        'pickup_lat': pos?.latitude,
        'pickup_lng': pos?.longitude,
        'status': 'requested',
        'estimated_fare': 10.00,
      });
      pickup.clear();
      destination.clear();
      setState(() => message = 'Solicitud enviada a Central.');
    } on PostgrestException catch (e) {
      setState(() => message = 'Error de Supabase: ${e.message}');
    } catch (e) {
      setState(() => message = 'No se pudo solicitar: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> cancelTrip(String id) async {
    try {
      await sb.rpc('passenger_cancel_trip', params: {'p_trip_id': id});
      if (mounted) setState(() => message = 'Viaje cancelado.');
    } catch (e) {
      if (mounted) setState(() => message = 'No se pudo cancelar: $e');
    }
  }

  Future<void> logout() async {
    await sb.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AppGate()),
      (_) => false,
    );
  }

  @override
  void dispose() {
    pickup.dispose();
    destination.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = sb.auth.currentUser?.id;
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚕 Radio Móvil Sacaba'),
        actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: tripStream,
        builder: (context, snap) {
          final rows = (snap.data ?? []).where((x) => x['passenger_id'] == uid).toList();
          final active = rows.where((x) => !['completed', 'cancelled'].contains(x['status'])).toList();
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text('Hola, ${widget.profile['full_name'] ?? 'Pasajero'}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(controller: pickup, decoration: const InputDecoration(labelText: 'Origen', prefixIcon: Icon(Icons.my_location))),
                      const SizedBox(height: 10),
                      TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destino', prefixIcon: Icon(Icons.location_on))),
                      const SizedBox(height: 14),
                      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : requestTrip, icon: const Icon(Icons.local_taxi), label: Text(busy ? 'ENVIANDO…' : 'SOLICITAR MÓVIL'))),
                      const SizedBox(height: 8),
                      Text(message, textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              if (active.isNotEmpty) ...[
                Text('Viaje en curso', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                ...active.map((trip) => TripCard(trip: trip, onCancel: () => cancelTrip(trip['id'].toString()))),
              ],
            ],
          );
        },
      ),
    );
  }
}

class DriverHome extends StatefulWidget {
  final Map<String, dynamic> profile;
  const DriverHome({super.key, required this.profile});

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final sb = Supabase.instance.client;
  bool available = false;
  bool busy = false;
  String message = 'Fuera de servicio';
  StreamSubscription<Position>? gps;

  Stream<List<Map<String, dynamic>>> get tripStream => sb
      .from('trips')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false);

  Future<Position?> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
  }

  Future<void> setAvailable(bool value) async {
    final uid = sb.auth.currentUser?.id;
    if (uid == null) return;
    setState(() => busy = true);
    try {
      final pos = await locate();
      if (pos == null) throw Exception('Activa la ubicación del teléfono.');
      await sb.rpc('driver_set_availability', params: {
        'p_available': value,
        'p_latitude': pos.latitude,
        'p_longitude': pos.longitude,
        'p_heading': pos.heading,
        'p_speed': pos.speed,
      });
      await gps?.cancel();
      gps = null;
      if (value) {
        gps = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10)).listen((position) async {
          try {
            await sb.rpc('driver_set_availability', params: {
              'p_available': true,
              'p_latitude': position.latitude,
              'p_longitude': position.longitude,
              'p_heading': position.heading,
              'p_speed': position.speed,
            });
          } catch (_) {}
        });
      }
      if (mounted) setState(() { available = value; message = value ? '🟢 Disponible para recibir carreras' : '⚪ Fuera de servicio'; });
    } catch (e) {
      if (mounted) setState(() => message = 'No se pudo cambiar disponibilidad: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> action(String next, String id) async {
    try {
      if (next == 'accepted') {
        await sb.rpc('driver_accept_trip', params: {'p_trip_id': id});
      } else if (next == 'arriving') {
        await sb.rpc('driver_start_arrival', params: {'p_trip_id': id});
      } else if (next == 'arrived') {
        await sb.rpc('driver_mark_arrived', params: {'p_trip_id': id});
      } else if (next == 'started') {
        final code = await askSecurityCode();
        if (code == null || code.isEmpty) return;
        await sb.rpc('driver_start_trip', params: {'p_trip_id': id, 'p_security_code': code});
      } else if (next == 'completed') {
        await sb.rpc('driver_finish_trip', params: {'p_trip_id': id, 'p_final_fare': 10.00});
      }
      if (mounted) setState(() => message = 'Acción realizada correctamente.');
    } on PostgrestException catch (e) {
      if (mounted) setState(() => message = 'No se pudo realizar la acción: ${e.message}');
    } catch (e) {
      if (mounted) setState(() => message = 'No se pudo realizar la acción: $e');
    }
  }

  Future<String?> askSecurityCode() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Código de seguridad del viaje'),
        content: TextField(controller: controller, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Código')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Validar')),
        ],
      ),
    );
    controller.dispose();
    return result;
  }

  Future<void> logout() async {
    await gps?.cancel();
    await sb.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AppGate()), (_) => false);
  }

  @override
  void dispose() {
    gps?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = sb.auth.currentUser?.id;
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚕 Conductor'),
        actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: tripStream,
        builder: (context, snap) {
          final rows = (snap.data ?? []).where((x) => x['driver_id'] == uid && ['assigned', 'accepted', 'arriving', 'arrived', 'started'].contains(x['status'])).toList();
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text('Hola, ${widget.profile['full_name'] ?? 'Conductor'}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Estado del conductor'), const SizedBox(height: 4), Text(message)])),
                      Switch(value: available, onChanged: busy ? null : setAvailable),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (rows.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('No tienes viajes asignados.'))),
              ...rows.map((trip) => DriverTripCard(trip: trip, onAction: action)),
            ],
          );
        },
      ),
    );
  }
}

class DriverTripCard extends StatelessWidget {
  final Map<String, dynamic> trip;
  final Future<void> Function(String next, String id) onAction;
  const DriverTripCard({super.key, required this.trip, required this.onAction});

  @override
  Widget build(BuildContext context) {
    final status = '${trip['status']}';
    String? next;
    String label = 'Viaje';
    if (status == 'assigned') { next = 'accepted'; label = 'ACEPTAR VIAJE'; }
    else if (status == 'accepted') { next = 'arriving'; label = 'VOY EN CAMINO'; }
    else if (status == 'arriving') { next = 'arrived'; label = 'YA LLEGUÉ'; }
    else if (status == 'arrived') { next = 'started'; label = 'INICIAR VIAJE'; }
    else if (status == 'started') { next = 'completed'; label = 'FINALIZAR VIAJE'; }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Estado: $status', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('📍 ${trip['pickup_address'] ?? '-'}'),
          Text('🏁 ${trip['destination_address'] ?? '-'}'),
          if (trip['security_code'] != null) ...[
            const SizedBox(height: 6),
            Text('Código del viaje: ${trip['security_code']}', style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
          if (next != null) ...[
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: () => onAction(next!, trip['id'].toString()), child: Text(label))),
          ],
        ]),
      ),
    );
  }
}

class TripCard extends StatelessWidget {
  final Map<String, dynamic> trip;
  final VoidCallback? onCancel;
  const TripCard({super.key, required this.trip, this.onCancel});

  String label(String status) => {
        'requested': 'Buscando conductor',
        'assigned': 'Conductor asignado',
        'accepted': 'Conductor aceptó',
        'arriving': 'Conductor en camino',
        'arrived': 'Conductor llegó',
        'started': 'Viaje iniciado',
        'completed': 'Viaje finalizado',
        'cancelled': 'Cancelado',
      }[status] ?? status;

  @override
  Widget build(BuildContext context) {
    final status = '${trip['status']}';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label(status), style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('📍 ${trip['pickup_address'] ?? '-'}'),
          Text('🏁 ${trip['destination_address'] ?? '-'}'),
          if (trip['security_code'] != null && ['assigned', 'accepted', 'arriving', 'arrived', 'started'].contains(status)) ...[
            const SizedBox(height: 6),
            Text('Código de viaje: ${trip['security_code']}', style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 6),
          Text('Tarifa: Bs ${trip['final_fare'] ?? trip['estimated_fare'] ?? '-'}'),
          if (onCancel != null && ['requested', 'assigned', 'accepted', 'arriving', 'arrived'].contains(status))
            Align(alignment: Alignment.centerRight, child: TextButton(onPressed: onCancel, child: const Text('Cancelar'))),
        ]),
      ),
    );
  }
}
