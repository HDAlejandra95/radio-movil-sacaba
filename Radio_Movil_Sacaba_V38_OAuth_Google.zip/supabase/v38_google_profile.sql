-- RADIO MÓVIL SACABA V38
-- Crear automáticamente un perfil de PASAJERO para nuevos usuarios OAuth (Google).
-- El trigger se ejecuta en Supabase al crear un usuario en auth.users.

create or replace function public.handle_new_user_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $func$
begin
  insert into public.profiles (id, full_name, phone, role, is_active)
  values (
    new.id,
    coalesce(
      nullif(new.raw_user_meta_data->>'full_name', ''),
      nullif(new.raw_user_meta_data->>'name', ''),
      nullif(new.email, ''),
      'Pasajero'
    ),
    null,
    'passenger',
    true
  )
  on conflict (id) do nothing;

  return new;
end;
$func$;

revoke all on function public.handle_new_user_profile() from public;

drop trigger if exists on_auth_user_created_profile on auth.users;

create trigger on_auth_user_created_profile
after insert on auth.users
for each row
execute function public.handle_new_user_profile();

select 'V38 GOOGLE PROFILE OK' as resultado;
